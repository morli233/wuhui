package com.example.qqhunter;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    private SwitchCompat switchEnable;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("qq_hunter_config", Context.MODE_PRIVATE);
        switchEnable = findViewById(R.id.switch_enable);

        boolean isEnabled = prefs.getBoolean("hook_enabled", false);
        switchEnable.setChecked(isEnabled);

        switchEnable.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("hook_enabled", isChecked).apply();
            Toast.makeText(MainActivity.this, 
                isChecked ? "✅ 监听已开启！请重启QQ生效" : "❌ 监听已关闭！请重启QQ生效", 
                Toast.LENGTH_LONG).show();
        });
    }
}
