package com.example.qqhunter;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.tencent.mobileqq")) {
            return;
        }

        try {
            Context context = (Context) XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", lpparam.classLoader),
                    "currentApplication"
            );

            if (context != null) {
                SharedPreferences prefs = context.getSharedPreferences("qq_hunter_config", Context.MODE_PRIVATE);
                if (!prefs.getBoolean("hook_enabled", false)) {
                    XposedBridge.log("QQ密保猎人: 开关已关闭，不注入");
                    return;
                }
                XposedBridge.log("QQ密保猎人: 开关已开启，注入Hook...");
            } else {
                return;
            }
        } catch (Throwable t) {
            XposedBridge.log("QQ密保猎人: 读取配置失败，跳过: " + t.getMessage());
            return;
        }

        XposedHelpers.findAndHookConstructor(
                String.class,
                byte[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String text = (String) param.thisObject;
                        if (text == null || text.length() < 20) return;

                        if (text.contains("bindSimPhone") || text.contains("etQQ")) {
                            String qq = extractValue(text, "\\"etQQ\\"");
                            String phone = extractValue(text, "\\"bindSimPhone\\"");
                            String addr = extractValue(text, "\\"deviceLoginAddress\\"");

                            if (qq != null || phone != null) {
                                String result = "========== 捕获时间: " + getCurrentTime() + " ==========\n";
                                if (qq != null) result += "QQ号: " + qq + "\n";
                                if (phone != null) result += "密保手机: " + phone + "\n";
                                if (addr != null) result += "登录地址: " + addr + "\n";
                                result += "======================================\n\n";

                                saveToFile(result);
                                showToast(context, "捕获成功！请查看 /sdcard/QQHunter.txt");
                            }
                        }
                    }
                }
        );
        XposedBridge.log("QQ密保猎人: 监听已就绪");
    }

    private String extractValue(String json, String key) {
        try {
            Pattern pattern = Pattern.compile(key + "\\"\\s*:\\s*\\"(\\d+)\\"");
            Matcher matcher = pattern.matcher(json);
            if (matcher.find()) {
                return matcher.group(1);
            }
        } catch (Exception e) {
            XposedBridge.log(e.getMessage());
        }
        return null;
    }

    private void saveToFile(String content) {
        try {
            File file = new File(Environment.getExternalStorageDirectory(), "QQHunter.txt");
            FileWriter writer = new FileWriter(file, true);
            writer.append(content);
            writer.flush();
            writer.close();
            XposedBridge.log("已写入: " + file.getAbsolutePath());
        } catch (IOException e) {
            XposedBridge.log("写入失败: " + e.getMessage());
        }
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private void showToast(Context context, String msg) {
        try {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            XposedBridge.log("弹窗失败: " + t.getMessage());
        }
    }
}
